<!DOCTYPE html>
<html>
    <head>
    <title>Advisors</title>
</head>
<body>
    <p>List of SSN and the name of Students<br>s1=student1</br>s2=student2
        <br>s3=gradstcse1</br>s4=student3
        <br>s5=student4</br>s6=gradstcse2
        <br></p>


    <form method="POST" action="">        
        <input type="text" name="ssn"> 
            <input type="submit"/> 
    </form>

    <?php
    include 'connect.php';
    $ssn = $_POST['ssn'] ?? 'default value';
    $query = "select s.advisorSsn,i.iname from student s,instructor i where s.advisorSsn=i.ssn and s.ssn = '$ssn'";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    mysqli_close($conn);
    ?>

     <h4>Instructors of University</h4>
    <table border="2" cellspacing="2" cellpadding="2">
        <tr>
            <th>Advisor SSN</th>
            <th>Advisor Name</th>
           
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            $advSsn=$row["advisorSsn"];
            $iname = $row["iname"];

            echo"<tr>"
            . "<td>$advSsn</td>"
            . "<td>$iname</td>"
            . "</tr>";
        }
        ?>

    </table>

    <P>
        <a href="HomePage.php">Return to main page</a>

</body>
</html>
