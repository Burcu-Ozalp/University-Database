<!DOCTYPE html>
<html>
    <head>
        <title>All Departments</title>
    </head>
    <body>

        <?php
        include 'connect.php';
        $query = "SELECT dName,budget,headSsn,buildingName FROM department";
        $result = mysqli_query($conn,$query);
        $num = mysqli_num_rows($result);
        mysqli_close($conn);
        ?>

        <h4>Departments of University</h4>
        <table border="2" cellspacing="2" cellpadding="2">
            <tr>
                <th>Department Name</th>
                <th>Department Budget</th>
                <th>Department Head SSN</th>
                <th>Department Building Name</th>
            </tr>

            <?php
            while($row= mysqli_fetch_assoc($result)){      
             $dName = $row["dName"];
             $budget = $row["budget"];
             $headSsn = $row["headSsn"];
             $buildingName = $row["buildingName"];
             echo"<tr>"
            . "<td>$dName</td>"
            . "<td>NULL</td>"
            . "<td>$headSsn</td>"
            . "<td>$buildingName</td>"    
            . "</tr>";}
                ?>

                <tr>
                    <td>
                        <a href="deptView.php?dName=<?php echo $dName; ?>"></a>
                    </td>
                </tr>
        </table>

        <P>
            <a href="HomePage.php">Return to main page</a>

    </body>
</html>
