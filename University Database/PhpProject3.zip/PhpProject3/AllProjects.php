<html>
    <head>
        <title>All Projects</title>
    </head>
    <body>

        <?php
        include 'connect.php';
        $query = "SELECT leadSsn,pName,subject,budget,startDate,enddate,controllingDName FROM project order by leadSsn";
        $result = mysqli_query($conn,$query);
        $num = mysqli_num_rows($result);
        mysqli_close($conn);
        ?>

        <h4>Projects of University</h4>
        <table border="2" cellspacing="2" cellpadding="2">
            <tr>
                <th><font face="Arial, Helvetica, sans-serif">Lead SSN</font></th>
                <th><font face="Arial, Helvetica, sans-serif">Project Name</font></th>
                <th><font face="Arial, Helvetica, sans-serif">Project Subject</font></th>
                <th><font face="Arial, Helvetica, sans-serif">Project Budget</font></th>
                <th><font face="Arial, Helvetica, sans-serif">Project Start Date</font></th>
                <th><font face="Arial, Helvetica, sans-serif">Project End Date</font></th>
                <th><font face="Arial, Helvetica, sans-serif">Controlling Department Name</font></th>
            </tr>

            <?php
            while($row= mysqli_fetch_assoc($result)){      
             $leadSsn= $row["leadSsn"];            
             $pName = $row["pName"]; 
             $subject = $row["subject"];
             $budget= $row["budget"];            
             $startDate = $row["startDate"]; 
             $endDate = $row["enddate"];
             $CDName = $row["controllingDName"];
             echo"<tr>"
            . "<td>$leadSsn</td>"
            . "<td>$pName</td>"
            . "<td>$subject</td>"         
            . "<td>$budget</td>"  
            . "<td>$startDate</td>"
            . "<td>$endDate</td>"         
            . "<td>$CDName</td>"        
            . "</tr>";                      
        }
                ?>

                <tr>
                    <td><font face="Arial, Helvetica, sans-serif">
                        <a href="projView.php?leadSsn=<?php echo $leadSsn; ?>"></a></font></td>
                </tr>


        </table>

        <P>
            <a href="HomePage.php">Return to main page</a>

    </body>
</html>
