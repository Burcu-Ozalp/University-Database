<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
    <title></title>
</head>
<body>
    <?php
    $dbname = "universitydb"; // name of database

$conn = mysqli_connect("127.0.0.1", "root", "", $dbname, '3306');

if ($conn->connect_errno) {

  echo "Failed to connect to MySQL: " . $conn->connect_error;

  exit();

} else {

  echo " ";

}
    ?>
</body>
</html>
