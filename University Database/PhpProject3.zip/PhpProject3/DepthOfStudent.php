<!DOCTYPE html>
<html>
    <head>
    <title>Department Of Students</title>
</head>
<body>
    <p>List of SSSN of students<br>s1</br>s2<br>s3</br>s4<br>s5</br>s6<br></p>

    <p>Please write ssn</p>
    <form method="POST" action="">        
        <input type="text" name="ssn"> 
            <input type="submit"/> 
    </form>

    <?php

    include 'connect.php';
    $ssn = $_POST['ssn'] ?? 'default value';
    $query = "select ssn,studentname,dName from student where ssn = '$ssn'";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    mysqli_close($conn);
    ?>

    <h4>Department of Student</h4>
    <table border="2" cellspacing="2" cellpadding="2">
        <tr>
            <th>SSN</th> 
            <th>Department Name</th>     
            <th>Student Name</th>  
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            $ssn = $row["ssn"];
            $studentname = $row["studentname"];
            $deptname = $row["dName"];
 
            echo"<tr>"
            . "<td>$ssn</td>"
            . "<td>$studentname</td>"
            . "<td>$deptname</td>"
            . "</tr>";
        }
        ?>

    </table>

    <P>
        <a href="HomePage.php">Return to main page</a>

</body>
</html>
