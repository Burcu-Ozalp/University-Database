<!DOCTYPE html>
<html>
    <head>
    <title>Exam Name</title>
</head>
<body>
    <p>List of SSN and the name of instructor<br>i1=Emine Ekin</br>i2=Caglar Aksezer
        <br>i3=Ozlem Inanc</br>i4=Elif Suyuk Makakli
        <br>i5=Banu Inanc Uyan Dur</br>i6=Olcay Yildiz
        <br>i7=instructor7</br>i8=instructor8
        <br>i9=Şirin Özlem</br></p>

    <p>Please write ssn</p>
    <form method="POST" action="">        
        <input type="text" name="ssn"> 
            <input type="submit"/> 
    </form>
    
    <?php
    include 'connect.php';
    $ssn = $_POST['ssn'] ?? 'default value';
    $semester = $_POST['semester'] ?? 'default value';
    $year = $_POST['yearr'] ?? 'default value';
    $query = "SELECT examname FROM examofsection WHERE issn='$ssn'";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    mysqli_close($conn);
    ?>

    </br>
    <table border="2" cellspacing="2" cellpadding="2">
        <tr>
            <th>Exam Name</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            $examName = $row["examname"];
            

            echo"<tr>"
            . "<td>$examName</td>"
            . "</tr>";
        }
        ?>

    </table>

    <P>
        <a href="HomePage.php">Return to main page</a>

</body>
</html>