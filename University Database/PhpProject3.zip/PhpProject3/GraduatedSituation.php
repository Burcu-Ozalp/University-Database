<!DOCTYPE html>
<html>
    <head>
    <title>Graduated Or Undergraduated</title>
</head>
<body>
    <p>List of SSN and the name of Students<br>s1=student1</br>s2=student2
        <br>s3=gradstcse1</br>s4=student3
        <br>s5=student4</br>s6=gradstcse2
        <br></p>


    <form method="POST" action="">        
        <input type="text" name="ssn"> 
            <input type="submit"/> 
    </form>

    <?php

    include 'connect.php';
    $ssn = $_POST['ssn'] ?? 'default value';
    $query = "SELECT gradorUgrad FROM student WHERE ssn='$ssn'";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    mysqli_close($conn);
    ?>

     <h4>Grad Or UGrad</h4>
    <table border="2" cellspacing="2" cellpadding="2">
        <tr>
            <th>Grad Or UGrad</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            $gradOrUgrad = $row["gradorUgrad"];
         
            echo"<tr>"
            . "<td>$gradOrUgrad</td>"
            . "</tr>";
        }
        ?>

    </table>

    <P>
        <a href="HomePage.php">Return to main page</a>

</body>
</html>