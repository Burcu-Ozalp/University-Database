<html>
<head>
<title>Home Page</title>
</head>
<body>
<P>
<a href="AllDepts.php">Departments</a>
<P>
<a href="AllProjects.php">Projects</a>
<P>
<a href="StudentChoices.php">Students</a>
<P>
<a href="InstructorChoices.php">Instructor</a>
</body>
</html>
