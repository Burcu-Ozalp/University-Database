<html>
<head>
<title>Instructor Choice</title>
</head>
<body>
<P>
<a href="SeeTheCourses.php">See The Courses</a>
<P>
<a href="WeeklyScheduleOfInst.php">Weekly Schedule</a>
<P>
<a href="StudentsOfCourse.php">Students of Course</a>
<P>
<a href="LeadingProjects.php">Leading Projects</a>
<P>
<a href="WorkingInProjInst.php">Working in Projects</a>
<P>
<a href="StudentsSHeIsAdvising.php">Adviced Student of Instructor</a>
<P>
<a href="SupervisorOfGraduateStudents.php">Suvervised Graduate student of Instructor</a>
<P>
<a href="FreeHours.php">Free Hours</a>
<P>
<a href="ExamsDeliveredByInst.php">Exams</a> 
<P>
<a href="Grades.php">Grades</a> 
</body>
</html>
