<html>
<head>
<title>Student Choice</title>
</head>
<body>
<P>
<a href="GraduatedSituation.php">See The Graduated Situation</a>
<P>
<a href="StudentTakingCourses.php">Taking Courses</a>
<P>
<a href="GradeReportStu.php">Grade Report</a>
<P>
<a href="WeeklyScheduleOfStudent.php">Weekly Schedule</a>#tabloyu eksik yapmış hoca
<P>
<a href="AdvisorOfStudent.php">Advisor</a>
<P>
<a href="curricula.php">List of Courses You Are Suppose To Take</a>
<P>
<a href="DepthOfStudent.php">Studying Department </a>
<P>
<a href="SupervisorOfProjectOfGraduate.php">Project Of Supervisor Of Graduate Student</a>
</body>
</html>
