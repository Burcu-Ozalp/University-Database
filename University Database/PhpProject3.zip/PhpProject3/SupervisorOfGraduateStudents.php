<!DOCTYPE html>
<html>
    <head>
    <title>Supervisor</title>
</head>
<body>
    <p>List of SSN and the name of instructor<br>i1=Emine Ekin</br>i2=Caglar Aksezer
        <br>i3=Ozlem Inanc</br>i4=Elif Suyuk Makakli
        <br>i5=Banu Inanc Uyan Dur</br>i6=Olcay Yildiz
        <br>i7=instructor7</br>i8=instructor8
        <br>i9=Şirin Özlem</br></p>


    <form method="POST" action="">        
        <input type="text" name="ssn"> 
            <input type="submit"/> 
    </form>

    <?php
    include 'connect.php';
    $ssn = $_POST['ssn'] ?? 'default value';
    $query = "SELECT ssn FROM gradstudent WHERE supervisorSsn='$ssn'";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    mysqli_close($conn);
    ?>

     <h4>Supervisor Of Graduate Student</h4>
    <table border="2" cellspacing="2" cellpadding="2">
        <tr>
            <th>Student SSN</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            $ssn = $row["ssn"];
            

            echo"<tr>"
            . "<td>$ssn</td>"
            . "</tr>";
        }
        ?>

    </table>

    <P>
        <a href="HomePage.php">Return to main page</a>

</body>
</html>