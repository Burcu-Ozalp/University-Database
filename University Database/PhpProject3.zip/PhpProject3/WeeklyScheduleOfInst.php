<!DOCTYPE html>
<html>
    <head>
    <title>Instructor Weekly Schedule</title>
</head>
<body>
    <p>List of SSN and the name of instructor<br>i1=Emine Ekin</br>i2=Caglar Aksezer
        <br>i3=Ozlem Inanc</br>i4=Elif Suyuk Makakli
        <br>i5=Banu Inanc Uyan Dur</br>i6=Olcay Yildiz
        <br>i7=instructor7</br>i8=instructor8
        <br>i9=Şirin Özlem</br></p>


    <form method="POST" action="">        
        <input type="text" name="ssn"> 
            <input type="submit"/> 
    </form>

    <?php
    #if(isset($ssn)){
    include 'connect.php';
    #$myValue = $_POST['myKey'] ?? 'default value';
    $ssn = $_POST['ssn'] ?? 'default value';
    #$query="select iname from instructor where ssn=$ssn";
    $query = "SELECT distinct w.issn,w.courseCode,w.sectionId,w.yearr,w.semester,w.dayy,w.hourr,w.buildingName,w.roomNumber FROM weeklyschedule w,sectionn s where s.issn=w.issn and w.issn='$ssn'";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    mysqli_close($conn);
    ?>

     <h4>Instructor Weekly Schedule</h4>
    <table border="2" cellspacing="2" cellpadding="2">
        <tr>
            <th>ISSN</th>
            <th>Course Code</th>
            <th>Course Code</th>
            <th>Section ID</th>
            <th>Year</th>
            <th>Semester</th>
            <th>Day</th>
            <th>Hour</th>
            <th>Building Name</th>
            <th>Room Number</th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            $issn = $row["issn"];
            $courseCode = $row["courseCode"];
            $sectionId = $row["sectionId"];
            $year = $row["yearr"];
            $semester = $row["semester"];
            $day = $row["dayy"];
            $hour = $row["hourr"];
            $buildingName = $row["buildingName"];
            $roomNumber = $row["roomNumber"];

            echo"<tr>"
            . "<td>$issn</td>"
            . "<td>$courseCode</td>"
            . "<td>$sectionId</td>"
            . "<td>$year</td>"
            . "<td>$semester</td>"
            . "<td>$day</td>"
            . "<td>$hour</td>"
            . "<td>$buildingName</td>"
            . "<td>$roomNumber</td>"
            . "</tr>";
        }
        ?>

    </table>

    <P>
        <a href="HomePage.php">Return to main page</a>

</body>
</html>
