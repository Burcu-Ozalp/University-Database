<!DOCTYPE html>
<html>
    <head>
    <title>Curricula</title>
</head>
<body>
    <p>List of Student Id of students<br>st1</br>st2<br>st3</br>st4<br>mscomp1</br>mscomp2<br></p>

    <p>Please write sssn</p>
    <form method="POST" action="">        
        <input type="text" name="studentid"> 
            <input type="submit"/> 
    </form>

    <?php
    include 'connect.php';
    $studentid = $_POST['studentid'] ?? 'default value';
    $query = "select c.courseCode, c.courseName, c.ects from course c where c.courseCode in (select cu.courseCode
						                                            from  curriculacourses CU, student S
                                                                                            where s.studentid = '$studentid' and s.currCode = CU.currCode and s.dname =CU.dname);";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    mysqli_close($conn);
    ?>

    <h4>Curricula</h4>
    <table border="2" cellspacing="2" cellpadding="2">
        <tr>
            <th>course code</th> 
            <th>Course Name</th>    
            <th>Course ECTS</th> 
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result)) {
            $coursecode = $row["courseCode"];
            $coursename = $row["courseName"];
            $ects = $row["ects"];
 
            echo"<tr>"
            . "<td>$coursecode</td>"
            . "<td>$coursename</td>"
            . "<td>$ects</td>"
            . "</tr>";
        }
        ?>

    </table>

    <P>
        <a href="HomePage.php">Return to main page</a>

</body>
</html>
